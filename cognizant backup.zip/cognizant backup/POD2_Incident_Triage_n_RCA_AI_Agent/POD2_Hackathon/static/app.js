const sampleSelect = document.querySelector("#sampleAlert");
const alertJson = document.querySelector("#alertJson");
const loadSample = document.querySelector("#loadSample");
const uploadJsonFile = document.querySelector("#uploadJsonFile");
const payloadForm = document.querySelector("#payloadForm");
const editorStatus = document.querySelector("#editorStatus");
const fieldId = document.querySelector("#fieldId");
const fieldService = document.querySelector("#fieldService");
const fieldAlertType = document.querySelector("#fieldAlertType");
const fieldSeverity = document.querySelector("#fieldSeverity");
const fieldRegion = document.querySelector("#fieldRegion");
const fieldTimestamp = document.querySelector("#fieldTimestamp");
const fieldErrorCode = document.querySelector("#fieldErrorCode");
const fieldDescription = document.querySelector("#fieldDescription");
const applyFormChanges = document.querySelector("#applyFormChanges");
const saveJsonPayload = document.querySelector("#saveJsonPayload");
const runTriage = document.querySelector("#runTriage");
const runGuidedDemo = document.querySelector("#runGuidedDemo");
const validatePayload = document.querySelector("#validatePayload");
const simulatePagerDuty = document.querySelector("#simulatePagerDuty");
const postSlack = document.querySelector("#postSlack");
const runtime = document.querySelector("#runtime");
const claudeStatus = document.querySelector("#claudeStatus");
const slackStatus = document.querySelector("#slackStatus");
const reportSource = document.querySelector("#reportSource");
const scenarioTiles = document.querySelector("#scenarioTiles");
const errorTiles = document.querySelector("#errorTiles");
const snapshotStatus = document.querySelector("#snapshotStatus");
const signalCards = document.querySelector("#signalCards");
const diagnosticsPanel = document.querySelector("#diagnosticsPanel");
const diagnosticsStatus = document.querySelector("#diagnosticsStatus");
const diagnosticsContent = document.querySelector("#diagnosticsContent");
const toggleDetails = document.querySelector("#toggleDetails");
const severityGauge = document.querySelector("#severityGauge");
const logChart = document.querySelector("#logChart");
const hypothesisChart = document.querySelector("#hypothesisChart");
const evidenceFlow = document.querySelector("#evidenceFlow");
const impactStatus = document.querySelector("#impactStatus");
const impactCards = document.querySelector("#impactCards");
const topologyStatus = document.querySelector("#topologyStatus");
const topologyMap = document.querySelector("#topologyMap");
const mitigationStatus = document.querySelector("#mitigationStatus");
const mitigationBoard = document.querySelector("#mitigationBoard");
const warRoomStatus = document.querySelector("#warRoomStatus");
const warRoomFeed = document.querySelector("#warRoomFeed");
const assignmentStatus = document.querySelector("#assignmentStatus");
const assignmentPanel = document.querySelector("#assignmentPanel");
const emailStatus = document.querySelector("#emailStatus");
const emailPanel = document.querySelector("#emailPanel");
const ackIncident = document.querySelector("#ackIncident");
const assignOwner = document.querySelector("#assignOwner");
const escalateIncident = document.querySelector("#escalateIncident");
const createFollowup = document.querySelector("#createFollowup");
const workflowStatus = document.querySelector("#workflowStatus");
const agentTimeline = document.querySelector("#agentTimeline");
const hypothesesEl = document.querySelector("#hypotheses");
const checklistEl = document.querySelector("#checklist");
const evidenceEl = document.querySelector("#evidence");
const incidentsEl = document.querySelector("#incidents");
const slackMessageEl = document.querySelector("#slackMessage");
const copyReport = document.querySelector("#copyReport");
const downloadReport = document.querySelector("#downloadReport");
const refreshChannel = document.querySelector("#refreshChannel");
const clearChannel = document.querySelector("#clearChannel");
const localChannelEl = document.querySelector("#localChannel");
const processingOverlay = document.querySelector("#processingOverlay");
const processingTitle = document.querySelector("#processingTitle");
const processingDetail = document.querySelector("#processingDetail");
const progressFill = document.querySelector("#progressFill");
const processingSteps = document.querySelector("#processingSteps");
const toast = document.querySelector("#toast");

let samples = [];
let errorPayloads = [];
let latestReport = null;
let progressTimer = null;
let toastTimer = null;
let detailsHidden = false;
let mitigationDone = new Set();
let warEvents = [];

const workflowSteps = [
  ["Alert", "payload"],
  ["Logs", "30 min window"],
  ["Tickets", "similar incidents"],
  ["Runbook", "known fixes"],
  ["Reason", "rank causes"],
  ["Notify", "incident channel"],
];

const workflowMessages = [
  "Reading alert fields and severity.",
  "Scanning logs in the 30 minute incident window.",
  "Searching similar historical incidents.",
  "Retrieving matching runbook actions.",
  "Ranking root-cause hypotheses from evidence.",
  "Preparing incident-channel notification.",
];

function pretty(value) {
  return JSON.stringify(value, null, 2);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function likelihoodClass(value) {
  return String(value || "").toLowerCase();
}

function likelihoodScore(value) {
  const normalized = String(value || "").toLowerCase();
  if (normalized === "high") {
    return 92;
  }
  if (normalized === "medium") {
    return 64;
  }
  if (normalized === "low") {
    return 34;
  }
  return 18;
}

function severityScore(value) {
  const normalized = String(value || "").toUpperCase();
  if (["P1", "SEV1", "CRITICAL"].includes(normalized)) {
    return 96;
  }
  if (["P2", "SEV2", "HIGH"].includes(normalized)) {
    return 72;
  }
  if (["P3", "MEDIUM"].includes(normalized)) {
    return 46;
  }
  if (["P4", "LOW"].includes(normalized)) {
    return 24;
  }
  return 12;
}

function severityColor(score) {
  if (score >= 85) {
    return "#b42318";
  }
  if (score >= 60) {
    return "#b45309";
  }
  if (score >= 35) {
    return "#0f766e";
  }
  return "#15803d";
}

function getCurrentAlert() {
  return JSON.parse(alertJson.value);
}

function unwrapPayload(payload) {
  if (payload && typeof payload === "object" && !Array.isArray(payload) && payload.payload) {
    return payload.payload;
  }
  if (Array.isArray(payload)) {
    return payload[0] || {};
  }
  return payload || {};
}

function ensureAlertId(alert) {
  if (alert.id) {
    return alert;
  }
  const service = String(alert.service || "uploaded-alert").toLowerCase().replace(/[^a-z0-9_-]+/g, "-");
  return { ...alert, id: `${service}-${Date.now()}` };
}

function syncEditorFromPayload(payload) {
  const alert = typeof payload === "object" && !Array.isArray(payload) ? payload : {};
  fieldId.value = alert.id || "";
  fieldService.value = alert.service || "";
  fieldAlertType.value = alert.alert_type || "";
  fieldSeverity.value = alert.severity || "P2";
  fieldRegion.value = alert.region || "";
  fieldTimestamp.value = alert.timestamp || "";
  fieldErrorCode.value = alert.error_code || "";
  fieldDescription.value = alert.description || "";
  editorStatus.textContent = "Synced";
}

function payloadFromEditor() {
  return {
    ...unwrapPayload(getCurrentAlert()),
    id: fieldId.value.trim(),
    service: fieldService.value.trim(),
    alert_type: fieldAlertType.value.trim(),
    severity: fieldSeverity.value.trim(),
    region: fieldRegion.value.trim(),
    timestamp: fieldTimestamp.value.trim(),
    error_code: fieldErrorCode.value.trim(),
    description: fieldDescription.value.trim(),
  };
}

function updateJsonFromEditor() {
  const alert = ensureAlertId(payloadFromEditor());
  alertJson.value = pretty(alert);
  syncEditorFromPayload(alert);
  renderSnapshot({
    alert_summary: alert,
    log_findings: {},
    similar_incidents: [],
    source: "edited",
  });
  renderVisuals({
    alert_summary: alert,
    log_findings: {},
    root_cause_hypotheses: [],
    similar_incidents: [],
    runbooks: [],
  });
  editorStatus.textContent = "Applied";
  return alert;
}

function nowTime() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function estimateImpact(report) {
  const severity = String(report?.alert_summary?.severity || "").toUpperCase();
  const matchedLogs = Number(report?.log_findings?.matched_count || 0);
  const similarCount = Number(report?.similar_incidents?.length || 0);
  const baseline = severity === "P1" || severity === "SEV1" || severity === "CRITICAL" ? 75 : severity === "P2" ? 45 : 25;
  const target = Math.max(8, baseline - 35 - similarCount * 4);
  const saved = Math.max(0, baseline - target);
  const risk = Math.min(100, severityScore(severity) + matchedLogs * 3);
  return { baseline, target, saved, risk };
}

function addWarEvent(title, detail) {
  warEvents.unshift({ title, detail, time: nowTime() });
  warEvents = warEvents.slice(0, 12);
  renderWarRoom();
}

function renderWarRoom() {
  warRoomStatus.textContent = warEvents.length ? `${warEvents.length} events` : "Standby";
  if (!warEvents.length) {
    warRoomFeed.classList.add("empty");
    warRoomFeed.textContent = "No war-room activity yet.";
    return;
  }
  warRoomFeed.classList.remove("empty");
  warRoomFeed.innerHTML = warEvents
    .map((event) => `
      <article class="war-event">
        <strong>${escapeHtml(event.title)}</strong>
        <span>${escapeHtml(event.time)} - ${escapeHtml(event.detail)}</span>
      </article>
    `)
    .join("");
}

function renderAssignmentWorkflow(result = null) {
  if (!result) {
    assignmentStatus.textContent = "Waiting";
    emailStatus.textContent = "Waiting";
    assignmentPanel.classList.add("empty");
    emailPanel.classList.add("empty");
    assignmentPanel.textContent = "Generate a report to assign an owner.";
    emailPanel.textContent = "Assigned owner email will appear here.";
    return;
  }
  const assignment = result.assignment;
  const email = result.email;
  assignmentStatus.textContent = assignment.number;
  emailStatus.textContent = email.status;
  assignmentPanel.classList.remove("empty");
  emailPanel.classList.remove("empty");
  assignmentPanel.innerHTML = `
    <article class="assignment-card success">
      <strong>${escapeHtml(assignment.assigned_to)}</strong>
      <span>${escapeHtml(assignment.assignment_group)}</span>
      <span>${escapeHtml(assignment.number)} - ${escapeHtml(assignment.priority)} priority</span>
      <span>${escapeHtml(assignment.short_description)}</span>
    </article>
  `;
  emailPanel.innerHTML = `
    <article class="assignment-card success">
      <strong>${escapeHtml(email.to)}</strong>
      <span>${escapeHtml(email.subject)}</span>
      <span>Sent at ${escapeHtml(email.sent_at)}</span>
      <span>${escapeHtml(email.id)}</span>
    </article>
  `;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || response.statusText);
    error.payload = data;
    throw error;
  }
  return data;
}

function showToast(message) {
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add("visible");
  toastTimer = setTimeout(() => {
    toast.classList.remove("visible");
  }, 2400);
}

function setButtonBusy(button, busy, label = "Working") {
  if (!button) {
    return;
  }
  if (!button.dataset.defaultText) {
    button.dataset.defaultText = button.textContent.trim();
  }
  button.disabled = busy;
  button.classList.toggle("is-loading", busy);
  if (busy) {
    button.innerHTML = `<span class="button-spinner" aria-hidden="true"></span><span>${escapeHtml(label)}</span>`;
  } else {
    button.textContent = button.dataset.defaultText;
  }
}

function showProcessingOverlay() {
  processingOverlay.classList.remove("hidden");
}

function hideProcessingOverlay() {
  processingOverlay.classList.add("hidden");
}

function updateProcessing(activeIndex, doneAll = false) {
  const safeIndex = Math.max(0, Math.min(activeIndex, workflowSteps.length - 1));
  processingTitle.textContent = doneAll ? "Report Ready" : `Agent Processing: ${workflowSteps[safeIndex][0]}`;
  processingDetail.textContent = doneAll ? "Structured triage report generated." : workflowMessages[safeIndex];
  progressFill.style.width = `${doneAll ? 100 : Math.round(((safeIndex + 1) / workflowSteps.length) * 100)}%`;
  processingSteps.innerHTML = workflowSteps
    .map(([name], index) => {
      const className = doneAll || index < safeIndex ? "done" : index === safeIndex ? "active" : "";
      return `<div class="processing-step ${className}">${escapeHtml(index + 1)}. ${escapeHtml(name)}</div>`;
    })
    .join("");
}

async function init() {
  const health = await getJson("/api/health");
  claudeStatus.textContent = health.use_claude_api
    ? `Claude API: enabled (${health.model})`
    : "Local AI: enabled";
  slackStatus.textContent = health.slack_configured ? "Real Slack: configured" : "Mock Slack: enabled";

  samples = await getJson("/api/alerts");
  errorPayloads = await getJson("/api/error-payloads");
  sampleSelect.innerHTML = samples
    .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.service)} - ${escapeHtml(item.alert_type)}</option>`)
    .join("");
  renderScenarioTiles();
  renderErrorTiles();
  renderWorkflow(-1);
  renderSnapshot();
  renderVisuals();
  renderImpact();
  renderTopology();
  renderMitigationBoard();
  renderWarRoom();
  renderAssignmentWorkflow();
  setSelectedSample();
  await loadLocalChannel();
}

function renderScenarioTiles() {
  scenarioTiles.innerHTML = samples
    .map((item) => `
      <button class="scenario-chip sev-${escapeHtml(String(item.severity || "").toLowerCase())}" type="button" data-id="${escapeHtml(item.id)}">
        ${escapeHtml(item.severity)} - ${escapeHtml(item.service)}
      </button>
    `)
    .join("");
}

function renderErrorTiles() {
  errorTiles.innerHTML = errorPayloads
    .map((item) => `
      <button class="scenario-chip" type="button" data-id="${escapeHtml(item.id)}">
        ${escapeHtml(item.label)}
      </button>
    `)
    .join("");
}

function setSelectedSample() {
  const selected = samples.find((item) => item.id === sampleSelect.value) || samples[0];
  alertJson.value = pretty(selected);
  syncEditorFromPayload(selected);
  document.querySelectorAll(".scenario-chip").forEach((button) => {
    button.classList.toggle("active", button.dataset.id === selected?.id);
  });
  hideDiagnostics();
  renderSnapshot({
    alert_summary: selected,
    log_findings: {},
    similar_incidents: [],
    source: "ready",
  });
  renderVisuals({
    alert_summary: selected,
    log_findings: {},
    root_cause_hypotheses: [],
    similar_incidents: [],
    runbooks: [],
  });
  renderImpact({
    alert_summary: selected,
    log_findings: {},
    root_cause_hypotheses: [],
    similar_incidents: [],
    runbooks: [],
  });
  renderTopology({
    alert_summary: selected,
    log_findings: {},
    root_cause_hypotheses: [],
    similar_incidents: [],
    runbooks: [],
  });
  renderMitigationBoard();
}

function setErrorPayload(errorCase) {
  alertJson.value = pretty(errorCase.payload);
  syncEditorFromPayload(unwrapPayload(errorCase.payload));
  document.querySelectorAll(".scenario-chip").forEach((button) => {
    button.classList.toggle("active", button.dataset.id === errorCase.id);
  });
  renderDiagnostics(
    "Loaded error case",
    [
      {
        field: errorCase.label,
        message: errorCase.description,
      },
    ],
    "warning"
  );
  renderSnapshot({
    alert_summary: typeof errorCase.payload === "object" && !Array.isArray(errorCase.payload) ? errorCase.payload : {},
    log_findings: {},
    similar_incidents: [],
    source: "error-test",
  });
  renderVisuals({
    alert_summary: typeof errorCase.payload === "object" && !Array.isArray(errorCase.payload) ? errorCase.payload : {},
    log_findings: {},
    root_cause_hypotheses: [],
    similar_incidents: [],
    runbooks: [],
  });
  renderImpact();
  renderTopology();
  renderMitigationBoard();
}

function hideDiagnostics() {
  diagnosticsPanel.classList.add("hidden");
  diagnosticsContent.innerHTML = "";
}

function renderDiagnostics(title, items, type = "error") {
  diagnosticsPanel.classList.remove("hidden");
  diagnosticsStatus.textContent = title;
  diagnosticsContent.innerHTML = (items || [])
    .map((item) => `
      <article class="diagnostic-item ${type === "warning" ? "warning-item" : ""}">
        <strong>${escapeHtml(item.field || "payload")}</strong>
        <span>${escapeHtml(item.message || item)}</span>
      </article>
    `)
    .join("");
}

function renderWorkflow(activeIndex, doneAll = false) {
  workflowStatus.textContent = doneAll ? "Complete" : activeIndex >= 0 ? workflowSteps[activeIndex]?.[0] || "Working" : "Idle";
  if (!processingOverlay.classList.contains("hidden") && activeIndex >= 0) {
    updateProcessing(activeIndex, doneAll);
  }
  agentTimeline.innerHTML = workflowSteps
    .map(([name, detail], index) => {
      const className = doneAll || index < activeIndex ? "done" : index === activeIndex ? "active" : "";
      return `
        <article class="timeline-step ${className}">
          <strong>${escapeHtml(index + 1)}. ${escapeHtml(name)}</strong>
          <span>${escapeHtml(detail)}</span>
        </article>
      `;
    })
    .join("");
}

function startWorkflowProgress() {
  clearInterval(progressTimer);
  let step = 0;
  showProcessingOverlay();
  updateProcessing(step);
  renderWorkflow(step);
  progressTimer = setInterval(() => {
    step = Math.min(step + 1, workflowSteps.length - 1);
    renderWorkflow(step);
  }, 450);
}

function stopWorkflowProgress() {
  clearInterval(progressTimer);
  progressTimer = null;
  updateProcessing(workflowSteps.length - 1, true);
  renderWorkflow(workflowSteps.length - 1, true);
}

function renderSnapshot(report = null, elapsedMs = null) {
  const summary = report?.alert_summary || {};
  const findings = report?.log_findings || {};
  const incidents = report?.similar_incidents || [];
  const source = report?.source || "waiting";
  snapshotStatus.textContent = elapsedMs ? `${(elapsedMs / 1000).toFixed(1)}s` : source;
  const updatedClass = elapsedMs ? " updated" : "";
  signalCards.innerHTML = [
    [summary.severity || "-", "Severity"],
    [summary.service || "-", "Service"],
    [findings.matched_count ?? "-", "Matched logs"],
    [incidents.length || "-", "Similar tickets"],
  ]
    .map(([value, label]) => `
      <article class="metric-card${updatedClass}">
        <strong>${escapeHtml(value)}</strong>
        <span>${escapeHtml(label)}</span>
      </article>
    `)
    .join("");
}

function renderBarChart(container, rows, emptyText) {
  if (!rows.length) {
    container.className = "chart-empty";
    container.textContent = emptyText;
    return;
  }
  const maxValue = Math.max(...rows.map((row) => row.value), 1);
  container.className = "bar-chart";
  container.innerHTML = rows
    .map((row) => {
      const width = Math.max(6, Math.round((row.value / maxValue) * 100));
      return `
        <div class="bar-row">
          <span class="bar-label">${escapeHtml(row.label)}</span>
          <span class="bar-track"><span class="bar-fill ${escapeHtml(row.tone || "")}" style="width:${width}%"></span></span>
          <span class="bar-value">${escapeHtml(row.display ?? row.value)}</span>
        </div>
      `;
    })
    .join("");
}

function renderVisuals(report = null) {
  const summary = report?.alert_summary || {};
  const severity = summary.severity || "-";
  const score = severityScore(severity);
  const color = severityColor(score);
  severityGauge.style.background = `conic-gradient(${color} ${Math.round(score * 3.6)}deg, #e8eef7 0deg)`;
  severityGauge.innerHTML = `
    <div class="gauge-core">
      <strong>${escapeHtml(severity)}</strong>
      <span>${escapeHtml(summary.service || "Severity")}</span>
    </div>
  `;

  const levelCounts = report?.log_findings?.level_counts || {};
  const logRows = Object.entries(levelCounts).map(([label, value]) => ({
    label,
    value: Number(value) || 0,
    tone: label.toLowerCase() === "error" ? "error" : label.toLowerCase() === "warn" ? "warn" : "ok",
  }));
  renderBarChart(logChart, logRows, "Run triage to populate log signal chart.");

  const hypothesisRows = (report?.root_cause_hypotheses || []).slice(0, 3).map((item) => ({
    label: `${item.rank}. ${item.hypothesis || "Hypothesis"}`,
    value: likelihoodScore(item.likelihood),
    display: item.likelihood || "Unknown",
    tone: likelihoodClass(item.likelihood) === "high" ? "error" : likelihoodClass(item.likelihood) === "medium" ? "warn" : "ok",
  }));
  renderBarChart(hypothesisChart, hypothesisRows, "Run triage to populate root-cause confidence.");

  const matchedLogs = report?.log_findings?.matched_count ?? 0;
  const incidentCount = report?.similar_incidents?.length ?? 0;
  const runbookCount = report?.runbooks?.length ?? 0;
  const hypothesisCount = report?.root_cause_hypotheses?.length ?? 0;
  evidenceFlow.innerHTML = [
    ["Alert", summary.service || "-", severity],
    ["Logs", "matched", matchedLogs],
    ["Tickets", "similar", incidentCount],
    ["Runbooks", "retrieved", runbookCount],
    ["Hypotheses", "ranked", hypothesisCount],
  ]
    .map(([title, label, value]) => `
      <article class="flow-node">
        <strong>${escapeHtml(title)}</strong>
        <span>${escapeHtml(label)}</span>
        <b>${escapeHtml(value)}</b>
      </article>
    `)
    .join("");
}

function renderImpact(report = null) {
  if (!report?.alert_summary) {
    impactStatus.textContent = "Waiting";
    impactCards.innerHTML = `
      <article class="impact-card"><strong>-</strong><span>Estimated MTTR saved</span></article>
      <article class="impact-card"><strong>-</strong><span>Target MTTR</span></article>
      <article class="impact-card"><strong>-</strong><span>Customer risk</span></article>
      <article class="impact-card"><strong>-</strong><span>Known-pattern match</span></article>
    `;
    return;
  }
  const impact = estimateImpact(report);
  const knownMatch = report.similar_incidents?.length ? "Yes" : "No";
  impactStatus.textContent = `${impact.saved} min saved`;
  impactCards.innerHTML = `
    <article class="impact-card good"><strong>${escapeHtml(impact.saved)}m</strong><span>Estimated MTTR saved</span></article>
    <article class="impact-card"><strong>${escapeHtml(impact.target)}m</strong><span>Target MTTR</span></article>
    <article class="impact-card ${impact.risk >= 80 ? "critical" : ""}"><strong>${escapeHtml(impact.risk)}%</strong><span>Customer risk</span></article>
    <article class="impact-card"><strong>${escapeHtml(knownMatch)}</strong><span>Known-pattern match</span></article>
  `;
}

function renderTopology(report = null) {
  const summary = report?.alert_summary || {};
  const service = summary.service || "service";
  const dependencies = report?.log_findings?.top_dependencies || [];
  const topDeps = dependencies.length ? dependencies.slice(0, 4) : ["logs", "tickets", "runbooks"];
  topologyStatus.textContent = report?.source ? `${topDeps.length} linked signals` : "Waiting";
  topologyMap.innerHTML = topDeps
    .map((dependency) => `
      <div class="topology-row">
        <article class="topology-node primary">
          <strong>${escapeHtml(service)}</strong>
          <span>${escapeHtml(summary.region || "region unknown")}</span>
        </article>
        <div class="topology-arrow">to</div>
        <article class="topology-node">
          <strong>${escapeHtml(dependency)}</strong>
          <span>correlated signal</span>
        </article>
      </div>
    `)
    .join("");
}

function renderMitigationBoard(report = null) {
  const steps = report?.remediation_checklist || [];
  if (!steps.length) {
    mitigationDone.clear();
    mitigationStatus.textContent = "0%";
    mitigationBoard.classList.add("empty");
    mitigationBoard.textContent = "Generate a report to create action cards.";
    return;
  }
  mitigationBoard.classList.remove("empty");
  mitigationBoard.innerHTML = steps
    .slice(0, 8)
    .map((step, index) => {
      const checked = mitigationDone.has(index);
      return `
        <label class="mitigation-card ${checked ? "done" : ""}">
          <input type="checkbox" data-index="${index}" ${checked ? "checked" : ""}>
          <span>${escapeHtml(step)}</span>
        </label>
      `;
    })
    .join("");
  const percent = Math.round((mitigationDone.size / Math.min(steps.length, 8)) * 100);
  mitigationStatus.textContent = `${Number.isFinite(percent) ? percent : 0}%`;
}

function renderReport(report, elapsedMs) {
  latestReport = report;
  hideDiagnostics();
  if (report.validation_warnings?.length) {
    renderDiagnostics(
      "Correlation warnings",
      report.validation_warnings.map((message) => ({ field: "warning", message })),
      "warning"
    );
  }
  reportSource.textContent = `${report.source || "unknown"} in ${(elapsedMs / 1000).toFixed(1)}s`;
  runtime.textContent = report.claude_error
    ? `Generated with local fallback. Claude note: ${report.claude_error}`
    : "Report generated successfully.";
  renderSnapshot(report, elapsedMs);
  renderVisuals(report);
  mitigationDone.clear();
  renderImpact(report);
  renderTopology(report);
  renderMitigationBoard(report);
  addWarEvent("AI report generated", `${report.alert_summary?.service || "Service"} triaged in ${(elapsedMs / 1000).toFixed(1)}s`);

  hypothesesEl.classList.remove("empty");
  hypothesesEl.innerHTML = (report.root_cause_hypotheses || [])
    .map((item) => {
      const evidence = (item.evidence || []).join(", ");
      return `
        <article class="hypothesis ${escapeHtml(likelihoodClass(item.likelihood))}">
          <h3>${escapeHtml(item.rank)}. ${escapeHtml(item.hypothesis)}</h3>
          <div class="meta">Likelihood: ${escapeHtml(item.likelihood)}</div>
          <p>${escapeHtml(item.reasoning)}</p>
          <div class="evidence-line">Evidence: ${escapeHtml(evidence)}</div>
        </article>
      `;
    })
    .join("");

  checklistEl.innerHTML = (report.remediation_checklist || [])
    .map((item) => `<li>${escapeHtml(item)}</li>`)
    .join("");

  const findings = report.log_findings || {};
  evidenceEl.innerHTML = `
    <div><strong>Correlation window:</strong> ${escapeHtml(report.correlation_window?.start)} to ${escapeHtml(report.correlation_window?.end)}</div>
    <div><strong>Matched logs:</strong> ${escapeHtml(findings.matched_count ?? "unknown")}</div>
    <div><strong>Log levels:</strong> ${escapeHtml(pretty(findings.level_counts || {}))}</div>
    <div><strong>Top error codes:</strong> ${escapeHtml((findings.top_error_codes || []).join(", "))}</div>
    <div><strong>Top dependencies:</strong> ${escapeHtml((findings.top_dependencies || []).join(", "))}</div>
    <div><strong>Escalation:</strong> ${escapeHtml(report.escalation_recommendation || "")}</div>
  `;

  incidentsEl.innerHTML = (report.similar_incidents || [])
    .slice(0, 3)
    .map((item) => `
      <article class="incident">
        <h3>${escapeHtml(item.ticket_id || item.title)} - ${escapeHtml(item.title || "")}</h3>
        <p>${escapeHtml(item.root_cause || item.symptoms || "")}</p>
        <p>Resolution: ${escapeHtml(item.resolution || "")}</p>
        <p>Score: ${escapeHtml(item.similarity_score ?? "n/a")}</p>
      </article>
    `)
    .join("");

  slackMessageEl.textContent = report.slack_message || "";
}

async function assignAndNotify(report) {
  assignmentStatus.textContent = "Assigning";
  emailStatus.textContent = "Sending";
  try {
    const result = await getJson("/api/mock-servicenow/assign", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ report }),
    });
    renderAssignmentWorkflow(result);
    addWarEvent("ServiceNow assigned", `${result.assignment.number} assigned to ${result.assignment.assigned_to}.`);
    addWarEvent("Email sent", `${result.email.id} sent to ${result.email.to}.`);
    showToast("Owner assigned and email sent.");
    return result;
  } catch (error) {
    assignmentStatus.textContent = "Failed";
    emailStatus.textContent = "Failed";
    addWarEvent("Assignment failed", error.message);
    showToast("Assignment/email failed.");
    return null;
  }
}

async function loadLocalChannel() {
  const messages = await getJson("/api/slack/messages");
  if (!messages.length) {
    localChannelEl.classList.add("empty");
    localChannelEl.textContent = "No incident reports posted yet.";
    return;
  }
  localChannelEl.classList.remove("empty");
  localChannelEl.innerHTML = messages
    .slice()
    .reverse()
    .map((item) => `
      <article class="channel-message">
        <h3>${escapeHtml(item.channel)} - ${escapeHtml(item.username)}</h3>
        <p>${escapeHtml(item.timestamp)}</p>
        <pre>${escapeHtml(item.text)}</pre>
      </article>
    `)
    .join("");
}

loadSample.addEventListener("click", async () => {
  setButtonBusy(loadSample, true, "Loading");
  await delay(160);
  setSelectedSample();
  setButtonBusy(loadSample, false);
  showToast("Sample alert loaded.");
});

uploadJsonFile.addEventListener("change", async () => {
  const file = uploadJsonFile.files?.[0];
  if (!file) {
    return;
  }
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const alert = ensureAlertId(unwrapPayload(parsed));
    alertJson.value = pretty(alert);
    syncEditorFromPayload(alert);
    renderSnapshot({
      alert_summary: alert,
      log_findings: {},
      similar_incidents: [],
      source: "uploaded",
    });
    renderVisuals({
      alert_summary: alert,
      log_findings: {},
      root_cause_hypotheses: [],
      similar_incidents: [],
      runbooks: [],
    });
    hideDiagnostics();
    editorStatus.textContent = "Uploaded";
    showToast(`Uploaded ${file.name}.`);
  } catch (error) {
    renderDiagnostics("Upload failed", [{ field: "file", message: error.message }]);
    showToast("Upload failed.");
  } finally {
    uploadJsonFile.value = "";
  }
});

payloadForm.addEventListener("input", () => {
  editorStatus.textContent = "Editing";
});

payloadForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    updateJsonFromEditor();
    hideDiagnostics();
    showToast("Form changes applied to JSON.");
  } catch (error) {
    renderDiagnostics("Form apply failed", [{ field: "json", message: error.message }]);
    showToast("Apply failed.");
  }
});

saveJsonPayload.addEventListener("click", async () => {
  setButtonBusy(saveJsonPayload, true, "Saving");
  try {
    const alert = updateJsonFromEditor();
    const result = await getJson("/api/alerts/save", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ alert }),
    });
    samples = await getJson("/api/alerts");
    sampleSelect.innerHTML = samples
      .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.service)} - ${escapeHtml(item.alert_type)}</option>`)
      .join("");
    sampleSelect.value = result.alert.id;
    renderScenarioTiles();
    syncEditorFromPayload(result.alert);
    alertJson.value = pretty(result.alert);
    editorStatus.textContent = `Saved: ${result.store}`;
    showToast("JSON saved locally.");
  } catch (error) {
    renderDiagnostics(
      error.payload?.error || "Save failed",
      error.payload?.details || [{ field: "request", message: error.message }]
    );
    showToast("Save failed.");
  } finally {
    setButtonBusy(saveJsonPayload, false);
  }
});
sampleSelect.addEventListener("change", setSelectedSample);
scenarioTiles.addEventListener("click", async (event) => {
  const button = event.target.closest(".scenario-chip");
  if (!button) {
    return;
  }
  setButtonBusy(button, true, "Loading");
  sampleSelect.value = button.dataset.id;
  await delay(120);
  setSelectedSample();
  setButtonBusy(button, false);
  showToast("Scenario selected.");
});

errorTiles.addEventListener("click", async (event) => {
  const button = event.target.closest(".scenario-chip");
  if (!button) {
    return;
  }
  const errorCase = errorPayloads.find((item) => item.id === button.dataset.id);
  if (!errorCase) {
    return;
  }
  setButtonBusy(button, true, "Loading");
  await delay(120);
  setErrorPayload(errorCase);
  setButtonBusy(button, false);
  showToast("Error test loaded.");
});

validatePayload.addEventListener("click", async () => {
  setButtonBusy(validatePayload, true, "Checking");
  try {
    const alert = getCurrentAlert();
    const report = await getJson("/api/local-ai/triage", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ alert }),
    });
    if (report.validation_warnings?.length) {
      renderDiagnostics(
        "Payload valid with warnings",
        report.validation_warnings.map((message) => ({ field: "warning", message })),
        "warning"
      );
    } else {
      renderDiagnostics("Payload valid", [{ field: "schema", message: "Alert payload is ready for triage." }], "warning");
    }
    addWarEvent("Payload validated", `${alert.service || "Alert"} passed local schema checks.`);
    showToast("Payload validation complete.");
  } catch (error) {
    renderDiagnostics(
      error.payload?.error || "Validation failed",
      error.payload?.details || [{ field: "request", message: error.message }]
    );
    showToast("Validation failed.");
  } finally {
    setButtonBusy(validatePayload, false);
  }
});

simulatePagerDuty.addEventListener("click", async () => {
  setButtonBusy(simulatePagerDuty, true, "Triggering");
  startWorkflowProgress();
  const started = performance.now();
  try {
    const alert = getCurrentAlert();
    const result = await getJson("/api/mock-pagerduty/events", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(alert),
    });
    const elapsed = performance.now() - started;
    stopWorkflowProgress();
    renderReport(result.triage_report, elapsed);
    await assignAndNotify(result.triage_report);
    await delay(420);
    hideProcessingOverlay();
    addWarEvent("Mock PagerDuty triggered", result.dedup_key || alert.id || "local event");
    showToast("Mock PagerDuty event triaged.");
  } catch (error) {
    clearInterval(progressTimer);
    renderWorkflow(-1);
    hideProcessingOverlay();
    renderDiagnostics(
      error.payload?.error || "Trigger failed",
      error.payload?.details || [{ field: "request", message: error.message }]
    );
    showToast("Mock trigger failed.");
  } finally {
    setButtonBusy(simulatePagerDuty, false);
  }
});

runGuidedDemo.addEventListener("click", async () => {
  setButtonBusy(runGuidedDemo, true, "Running");
  const preferred = samples.find((item) => item.id === "alert-orders-kafka-lag") || samples[0];
  sampleSelect.value = preferred.id;
  setSelectedSample();
  addWarEvent("Guided demo started", `${preferred.service} scenario loaded.`);
  await delay(350);
  const report = await generateCurrentReport(runGuidedDemo, true);
  if (report) {
    addWarEvent("Guided demo complete", "Report generated and posted to incident channel.");
  }
  setButtonBusy(runGuidedDemo, false);
});

async function generateCurrentReport(button = runTriage, postAfter = false) {
  setButtonBusy(button, true, "Generating");
  runtime.textContent = "Correlating logs, tickets, and runbooks...";
  startWorkflowProgress();
  const started = performance.now();
  try {
    const alert = getCurrentAlert();
    const report = await getJson("/api/triage", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ alert }),
    });
    const elapsed = performance.now() - started;
    stopWorkflowProgress();
    renderReport(report, elapsed);
    await assignAndNotify(report);
    await delay(420);
    hideProcessingOverlay();
    showToast("Triage report generated.");
    if (postAfter) {
      await postReportToChannel();
    }
    return report;
  } catch (error) {
    clearInterval(progressTimer);
    renderWorkflow(-1);
    hideProcessingOverlay();
    runtime.textContent = `Failed: ${error.message}`;
    renderDiagnostics(
      error.payload?.error || "Validation failed",
      error.payload?.details || [{ field: "request", message: error.message }]
    );
    showToast("Report generation failed.");
    return null;
  } finally {
    setButtonBusy(button, false);
  }
}

runTriage.addEventListener("click", async () => {
  await generateCurrentReport(runTriage);
});

copyReport.addEventListener("click", async () => {
  const text = slackMessageEl.textContent;
  if (!text) {
    runtime.textContent = "Generate a report before copying.";
    showToast("No report to copy yet.");
    return;
  }
  setButtonBusy(copyReport, true, "Copying");
  try {
    await navigator.clipboard.writeText(text);
    runtime.textContent = "Slack message copied.";
    showToast("Report copied.");
  } catch (error) {
    runtime.textContent = `Copy failed: ${error.message}`;
    showToast("Copy failed.");
  } finally {
    setButtonBusy(copyReport, false);
  }
});

downloadReport.addEventListener("click", async () => {
  if (!latestReport) {
    runtime.textContent = "Generate a report before downloading.";
    showToast("No report to download yet.");
    return;
  }
  setButtonBusy(downloadReport, true, "Saving");
  await delay(180);
  const blob = new Blob([pretty(latestReport)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `triage-report-${latestReport.alert_summary?.service || "incident"}.json`;
  link.click();
  URL.revokeObjectURL(url);
  runtime.textContent = "Report downloaded.";
  setButtonBusy(downloadReport, false);
  showToast("Report downloaded.");
});

async function postReportToChannel(button = postSlack) {
  const message = latestReport?.slack_message || slackMessageEl.textContent;
  if (!message) {
    runtime.textContent = "Generate a report before posting to Slack.";
    showToast("Generate a report first.");
    return null;
  }
  setButtonBusy(button, true, "Posting");
  try {
    const result = await getJson("/api/slack", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ message }),
    });
    runtime.textContent = result.message;
    await loadLocalChannel();
    addWarEvent("Posted incident update", "Triage report published to local incident channel.");
    showToast("Posted to incident channel.");
    return result;
  } catch (error) {
    runtime.textContent = `Slack failed: ${error.message}`;
    showToast("Post failed.");
    return null;
  } finally {
    setButtonBusy(button, false);
  }
}

postSlack.addEventListener("click", async () => {
  await postReportToChannel(postSlack);
});

mitigationBoard.addEventListener("change", (event) => {
  const input = event.target.closest("input[type='checkbox']");
  if (!input) {
    return;
  }
  const index = Number(input.dataset.index);
  if (input.checked) {
    mitigationDone.add(index);
    addWarEvent("Mitigation step completed", `Step ${index + 1} checked off.`);
  } else {
    mitigationDone.delete(index);
    addWarEvent("Mitigation step reopened", `Step ${index + 1} moved back to active.`);
  }
  renderMitigationBoard(latestReport);
});

ackIncident.addEventListener("click", () => {
  const service = latestReport?.alert_summary?.service || "current incident";
  addWarEvent("Incident acknowledged", `${service} is now owned by on-call engineer.`);
  showToast("Incident acknowledged.");
});

assignOwner.addEventListener("click", () => {
  const service = latestReport?.alert_summary?.service || "service";
  addWarEvent("Owner assigned", `${service} owner: Platform On-Call.`);
  showToast("Owner assigned.");
});

escalateIncident.addEventListener("click", async () => {
  const message = latestReport?.escalation_recommendation || "Escalation requested for current incident.";
  addWarEvent("Escalation requested", message);
  await post_to_local_channel_safe(`:warning: *Escalation requested*\n${message}`);
  showToast("Escalation recorded.");
});

createFollowup.addEventListener("click", () => {
  const service = latestReport?.alert_summary?.service || "service";
  const ticketId = `FOLLOW-${String(Date.now()).slice(-5)}`;
  addWarEvent("Follow-up created", `${ticketId} for ${service} prevention actions.`);
  showToast("Follow-up created.");
});

async function post_to_local_channel_safe(message) {
  try {
    await getJson("/api/mock-slack/webhook", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ channel: "#incident-triage", text: message }),
    });
    await loadLocalChannel();
  } catch {
    runtime.textContent = "Local channel post failed.";
  }
}

refreshChannel.addEventListener("click", async () => {
  setButtonBusy(refreshChannel, true, "Refreshing");
  try {
    await loadLocalChannel();
    runtime.textContent = "Local incident channel refreshed.";
    showToast("Channel refreshed.");
  } catch (error) {
    runtime.textContent = `Refresh failed: ${error.message}`;
    showToast("Refresh failed.");
  } finally {
    setButtonBusy(refreshChannel, false);
  }
});

clearChannel.addEventListener("click", async () => {
  setButtonBusy(clearChannel, true, "Clearing");
  try {
    const result = await getJson("/api/slack/clear", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    runtime.textContent = result.message;
    await loadLocalChannel();
    showToast("Channel cleared.");
  } catch (error) {
    runtime.textContent = `Clear failed: ${error.message}`;
    showToast("Clear failed.");
  } finally {
    setButtonBusy(clearChannel, false);
  }
});

toggleDetails.addEventListener("click", () => {
  detailsHidden = !detailsHidden;
  document.body.classList.toggle("details-collapsed", detailsHidden);
  toggleDetails.textContent = detailsHidden ? "Show Details" : "Hide Details";
  showToast(detailsHidden ? "Detailed text hidden." : "Detailed text visible.");
});

init().catch((error) => {
  runtime.textContent = `Startup failed: ${error.message}`;
});
