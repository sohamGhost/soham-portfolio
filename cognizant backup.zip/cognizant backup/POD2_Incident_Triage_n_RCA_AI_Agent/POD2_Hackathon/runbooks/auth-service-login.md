# Auth Service Login Failure Runbook

Service: auth-service
Alert types: login failures, token validation errors

## Known Failure Modes

- JWKS endpoint timeout or stale JWKS cache.
- Identity provider certificate rotation without local refresh.
- Regional identity provider degradation.

## Diagnostic Checklist

- [ ] Check login failure rate by region and client platform.
- [ ] Verify identity-provider JWKS endpoint latency and error rate.
- [ ] Force refresh the JWKS cache on affected auth-service pods.
- [ ] Check certificate rotation timestamp from the identity provider.
- [ ] Restart pods only after confirming cache refresh did not recover validation.
- [ ] Escalate to Identity Platform if JWKS endpoint remains degraded.
