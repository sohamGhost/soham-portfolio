# Billing Worker Queue Runbook

Service: billing-worker
Alert types: invoice queue backlog, tax API timeout, dead-letter growth

## Known Failure Modes

- Tax API timeout causes invoice job retries and worker saturation.
- New batching deployment increases processing time per invoice.
- Dead-letter queue grows after repeated external dependency failures.

## Diagnostic Checklist

- [ ] Check invoice queue backlog, oldest message age, retry count, and DLQ count.
- [ ] Verify tax-api latency, error rate, and timeout percentage.
- [ ] Enable cached tax rate fallback if tax-api is degraded.
- [ ] Scale billing-worker consumers if dependency health is stable.
- [ ] Pause retry storms by increasing backoff and limiting max attempts.
- [ ] Rollback the latest billing-worker deployment if backlog started after release.
- [ ] Replay DLQ only after root cause is mitigated.
- [ ] Escalate to Billing Platform and Finance Operations if invoice SLA is breached.
