# Inventory API Latency Runbook

Service: inventory-api
Alert types: p95 latency breach, cart reservation timeout

## Known Failure Modes

- Redis command queue saturation from hot SKU keys.
- Warehouse sync timeout while reservation locks are held.
- Deployment regression in reservation batching.

## Diagnostic Checklist

- [ ] Check inventory-api p95 latency and timeout rate by region.
- [ ] Verify redis-inventory command queue depth and hot keys.
- [ ] Check reservation lock age and stale lock count.
- [ ] Compare latency before and after the latest deployment.
- [ ] Scale Redis read replicas if queue depth is rising.
- [ ] Enable SKU key spreading for hot products.
- [ ] Restart stuck warehouse-sync workers if locks are held longer than 90 seconds.
- [ ] Escalate to Inventory and Cache Reliability if checkout cart updates are failing.
