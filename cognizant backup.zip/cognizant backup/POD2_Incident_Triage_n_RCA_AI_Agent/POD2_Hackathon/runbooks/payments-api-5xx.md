# Payments API 5xx Runbook

Service: payments-api
Alert types: 5xx error rate spike, checkout authorization failures

## Known Failure Modes

- Database connection pool exhaustion after deployment or traffic burst.
- Risk scoring dependency timeout causing retry amplification.
- Bad canary deployment increasing transaction duration.

## Diagnostic Checklist

- [ ] Check payments-api 5xx rate, checkout authorization failures, and p95 latency.
- [ ] Verify database pool metrics: active connections, idle connections, waiters, and maxPoolSize.
- [ ] Check for deployment events in the 30 minutes before the alert.
- [ ] Compare canary and stable version error rates.
- [ ] Verify risk-score-api latency and retry budget consumption.
- [ ] Rollback the latest canary if error rate is higher on the new version.
- [ ] Scale payments-api pods if CPU is saturated and database pool is healthy.
- [ ] Escalate to Payments Platform and Database Reliability for P1 customer checkout impact.

## Fast Mitigations

- Roll back the latest payments-api deployment.
- Temporarily raise database connection pool only with database owner approval.
- Disable synchronous risk scoring using the emergency feature flag if risk-score-api is degraded.
