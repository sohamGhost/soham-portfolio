# Profile Service Cache Runbook

Service: profile-service
Alert types: cache miss spike, profile read latency

## Known Failure Modes

- Cache eviction removes hot profile keys.
- Cache warmup queue falls behind live traffic.
- Database read traffic increases after cache miss spike.

## Diagnostic Checklist

- [ ] Check cache miss ratio, eviction count, and hot-key distribution.
- [ ] Verify profile-cache memory, CPU, and connection saturation.
- [ ] Check user-db p95 latency and read QPS after the miss spike.
- [ ] Run targeted cache warmup for top profile keys.
- [ ] Increase profile-cache memory or add nodes if eviction pressure continues.
- [ ] Rate-limit expensive profile reads until cache hit ratio recovers.
- [ ] Escalate to Profile Platform and Database Reliability if user-db latency keeps rising.
