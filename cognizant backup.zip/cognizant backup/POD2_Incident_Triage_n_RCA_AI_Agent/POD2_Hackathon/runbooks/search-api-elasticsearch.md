# Search API Elasticsearch Runbook

Service: search-api
Alert types: search 503, shard failures, Elasticsearch circuit breaker

## Known Failure Modes

- Query expansion or synonym rollout creates high-memory Elasticsearch requests.
- Shard relocation leaves hot shards under-replicated.
- Heap pressure trips the parent circuit breaker and rejects search requests.

## Diagnostic Checklist

- [ ] Check search-api 503 rate and top failing query templates.
- [ ] Verify Elasticsearch heap usage, rejected requests, and circuit breaker counters.
- [ ] Check shard allocation, relocating shards, and hot node distribution.
- [ ] Disable expensive query features such as synonym expansion if failures started after deployment.
- [ ] Cancel long-running search tasks and reduce result window size.
- [ ] Route read traffic away from unhealthy nodes if shard allocation allows.
- [ ] Rollback the latest search-api deployment if only the new query path is failing.
- [ ] Escalate to Search Platform and Data Infrastructure for P1 search outage.
