# Orders API Kafka Lag Runbook

Service: orders-api
Alert types: consumer lag, order processing failures, fulfillment delay

## Known Failure Modes

- Kafka broker instability or partition rebalance delays order-created consumption.
- New event mapper or validation path slows consumer throughput.
- Fulfillment dependency timeout causes consumer retries and commit delays.

## Diagnostic Checklist

- [ ] Check order-created consumer lag by partition and consumer group.
- [ ] Verify Kafka broker health, under-replicated partitions, and recent rebalances.
- [ ] Compare consumer throughput before and after the latest orders-api deployment.
- [ ] Check fulfillment-service timeout and retry rates.
- [ ] Scale orders-api consumer replicas if lag is rising and broker health is stable.
- [ ] Rollback the latest consumer mapper deployment if lag is isolated to the new version.
- [ ] Reassign hot partitions or pause low-priority consumers if brokers are overloaded.
- [ ] Escalate to Order Platform and Kafka Reliability for P1 paid-order fulfillment delay.
