# Notification Service Provider Runbook

Service: notification-service
Alert types: email delivery failures, provider throttling

## Known Failure Modes

- Shared email provider quota exhausted by marketing or batch traffic.
- Provider returns 429 rate limits for transactional templates.
- Retry queue grows and delays password reset or order confirmation emails.

## Diagnostic Checklist

- [ ] Check provider 429 rate by template and sender pool.
- [ ] Verify retry queue depth and oldest queued notification age.
- [ ] Pause non-critical campaign sends if transactional messages are impacted.
- [ ] Route transactional templates to the secondary provider.
- [ ] Increase backoff and jitter to avoid retry amplification.
- [ ] Drain retry queue after provider quota recovers.
- [ ] Escalate to Notification Platform and Customer Support if password reset emails are delayed.
