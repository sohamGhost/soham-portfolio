from __future__ import annotations

import json
import os
import re
import traceback
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
RUNBOOK_DIR = ROOT / "runbooks"
STATIC_DIR = ROOT / "static"
ERROR_PAYLOAD_DIR = DATA_DIR / "error_payloads"
LOCAL_SLACK_PATH = DATA_DIR / "local_slack_messages.json"
SERVICE_OWNERS_PATH = DATA_DIR / "service_owners.json"
SERVICENOW_ASSIGNMENTS_PATH = DATA_DIR / "servicenow_assignments.json"
EMAIL_OUTBOX_PATH = DATA_DIR / "mock_email_outbox.json"
UPLOADED_ALERTS_PATH = DATA_DIR / "uploaded_alerts.json"
HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "8000"))
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")
ANTHROPIC_VERSION = os.environ.get("ANTHROPIC_VERSION", "2023-06-01")
USE_CLAUDE_API = os.environ.get("USE_CLAUDE_API", "0").lower() in {"1", "true", "yes"}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def list_named_json_files(path: Path) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for file_path in sorted(path.glob("*.json")):
        payload = read_json(file_path)
        items.append(
            {
                "id": file_path.stem,
                "label": payload.get("label", file_path.stem.replace("_", " ").title()) if isinstance(payload, dict) else file_path.stem,
                "description": payload.get("description", "Error test payload") if isinstance(payload, dict) else "Error test payload",
                "payload": payload.get("payload", payload) if isinstance(payload, dict) else payload,
            }
        )
    return items


def load_list(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    payload = read_json(path)
    return payload if isinstance(payload, list) else []


def load_all_alerts() -> list[dict[str, Any]]:
    alerts = load_list(DATA_DIR / "sample_alerts.json")
    uploaded = load_list(UPLOADED_ALERTS_PATH)
    known_ids = {item.get("id") for item in alerts}
    for item in uploaded:
        if item.get("id") not in known_ids:
            alerts.append(item)
    return alerts


def save_alert_payload(alert: dict[str, Any]) -> dict[str, Any]:
    validation = validation_error_response(alert)
    if validation:
        return {"saved": False, **validation}

    alert_id = alert.get("id") or f"uploaded-{str(alert.get('service', 'service')).lower()}-{int(datetime.now(timezone.utc).timestamp())}"
    alert["id"] = re.sub(r"[^a-zA-Z0-9_-]+", "-", str(alert_id)).strip("-").lower()

    sample_path = DATA_DIR / "sample_alerts.json"
    samples = load_list(sample_path)
    for index, item in enumerate(samples):
        if item.get("id") == alert["id"]:
            samples[index] = alert
            write_json(sample_path, samples)
            return {"saved": True, "store": "sample_alerts", "alert": alert}

    uploaded = load_list(UPLOADED_ALERTS_PATH)
    for index, item in enumerate(uploaded):
        if item.get("id") == alert["id"]:
            uploaded[index] = alert
            write_json(UPLOADED_ALERTS_PATH, uploaded)
            return {"saved": True, "store": "uploaded_alerts", "alert": alert}

    uploaded.append(alert)
    write_json(UPLOADED_ALERTS_PATH, uploaded)
    return {"saved": True, "store": "uploaded_alerts", "alert": alert}


def find_service_owner(service: str | None) -> dict[str, str]:
    owners = read_json(SERVICE_OWNERS_PATH) if SERVICE_OWNERS_PATH.exists() else {}
    fallback = owners.get(
        "default",
        {
            "name": "Platform On-Call",
            "email": "platform-oncall@example.local",
            "team": "Platform Reliability",
        },
    )
    return owners.get(str(service or "").lower(), fallback)


def priority_from_severity(severity: str | None) -> str:
    normalized = str(severity or "").upper()
    if normalized in {"P1", "SEV1", "CRITICAL"}:
        return "Critical"
    if normalized in {"P2", "SEV2", "HIGH"}:
        return "High"
    if normalized in {"P3", "MEDIUM"}:
        return "Moderate"
    return "Low"


def validate_alert_payload(alert: Any) -> list[dict[str, str]]:
    errors: list[dict[str, str]] = []
    if not isinstance(alert, dict):
        return [{"field": "payload", "message": "Alert payload must be a JSON object."}]

    required_fields = ["service", "alert_type", "severity", "region", "timestamp", "error_code", "description"]
    for field in required_fields:
        if field not in alert or alert.get(field) in {"", None}:
            errors.append({"field": field, "message": f"`{field}` is required."})

    if alert.get("timestamp"):
        try:
            parse_ts(str(alert["timestamp"]))
        except Exception:
            errors.append(
                {
                    "field": "timestamp",
                    "message": "`timestamp` must be ISO-8601, for example 2026-06-25T09:42:00Z.",
                }
            )

    severity = str(alert.get("severity", "")).upper()
    if severity and severity not in {"P1", "P2", "P3", "P4", "SEV1", "SEV2", "CRITICAL", "HIGH", "MEDIUM", "LOW"}:
        errors.append({"field": "severity", "message": "`severity` should be one of P1, P2, P3, P4, SEV1, SEV2, CRITICAL, HIGH, MEDIUM, LOW."})

    return errors


def validation_error_response(alert: Any) -> dict[str, Any] | None:
    errors = validate_alert_payload(alert)
    if not errors:
        return None
    return {
        "error": "Invalid alert payload",
        "details": errors,
        "expected_schema": {
            "service": "payments-api",
            "alert_type": "5xx error rate spike",
            "severity": "P1",
            "region": "us-east-1",
            "timestamp": "2026-06-25T09:42:00Z",
            "error_code": "HTTP_503",
            "description": "Short impact description",
        },
    }


def correlation_warnings(
    log_summary: dict[str, Any],
    similar_incidents: list[dict[str, Any]],
    runbooks: list[dict[str, Any]],
) -> list[str]:
    warnings: list[str] = []
    if log_summary.get("matched_count", 0) == 0:
        warnings.append("No logs matched the service, region, and 30-minute alert window.")
    if not similar_incidents:
        warnings.append("No historical Jira/ServiceNow-style incidents were similar enough to rank.")
    if not runbooks:
        warnings.append("No runbook matched the affected service or alert type.")
    return warnings


def parse_ts(value: str) -> datetime:
    value = value.replace("Z", "+00:00")
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def iso_z(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def tokenize(text: str) -> set[str]:
    return {
        token
        for token in re.findall(r"[a-z0-9_/-]+", text.lower())
        if len(token) > 2 and token not in {"the", "and", "for", "with", "from", "this", "that"}
    }


def text_similarity(left: str, right: str) -> float:
    left_tokens = tokenize(left)
    right_tokens = tokenize(right)
    if not left_tokens or not right_tokens:
        return 0.0
    return len(left_tokens & right_tokens) / len(left_tokens | right_tokens)


def load_runbooks() -> list[dict[str, str]]:
    runbooks: list[dict[str, str]] = []
    for path in sorted(RUNBOOK_DIR.glob("*.md")):
        content = path.read_text(encoding="utf-8")
        title_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else path.stem
        runbooks.append({"id": path.stem, "title": title, "content": content})
    return runbooks


def extract_checklist(markdown: str) -> list[str]:
    items: list[str] = []
    for line in markdown.splitlines():
        stripped = line.strip()
        if stripped.startswith("- [ ] "):
            items.append(stripped[6:].strip())
        elif stripped.startswith("- "):
            clean = stripped[2:].strip()
            if any(word in clean.lower() for word in ("check", "verify", "restart", "rollback", "scale", "escalate")):
                items.append(clean)
    return items[:8]


def summarize_logs(alert: dict[str, Any], logs: list[dict[str, Any]]) -> dict[str, Any]:
    alert_time = parse_ts(alert["timestamp"])
    window_start = alert_time - timedelta(minutes=30)
    window_end = alert_time
    service = alert.get("service", "").lower()
    region = alert.get("region", "").lower()

    correlated: list[dict[str, Any]] = []
    deployment_events: list[dict[str, Any]] = []
    for entry in logs:
        ts = parse_ts(entry["timestamp"])
        if not window_start <= ts <= window_end:
            continue
        entry_service = entry.get("service", "").lower()
        entry_region = entry.get("region", "").lower()
        category = entry.get("category", "").lower()
        if entry_service == service or entry_region == region or category == "deployment":
            if category == "deployment":
                deployment_events.append(entry)
            else:
                correlated.append(entry)

    level_counts = Counter(entry.get("level", "UNKNOWN") for entry in correlated)
    error_codes = Counter(entry.get("error_code") for entry in correlated if entry.get("error_code"))
    dependencies = Counter(entry.get("dependency") for entry in correlated if entry.get("dependency"))
    exception_terms = [
        entry
        for entry in correlated
        if any(term in entry.get("message", "").lower() for term in ("timeout", "exception", "exhausted", "refused", "sqlstate"))
    ]

    return {
        "window": {"start": iso_z(window_start), "end": iso_z(window_end)},
        "matched_count": len(correlated),
        "level_counts": dict(level_counts),
        "top_error_codes": error_codes.most_common(5),
        "top_dependencies": dependencies.most_common(5),
        "important_logs": correlated[:12],
        "exception_logs": exception_terms[:8],
        "deployment_events": deployment_events[:5],
    }


def local_stack_status() -> dict[str, Any]:
    return {
        "mode": "local-only",
        "api_keys_required": False,
        "description": "Self-contained incident platform that mimics the suggested production stack with local JSON, Markdown, and Python APIs.",
        "replacements": [
            {
                "suggested": "Claude Sonnet API",
                "local_replacement": "Local AI reasoning engine",
                "endpoint": "POST /api/local-ai/triage",
                "api_key_required": False,
            },
            {
                "suggested": "PagerDuty API",
                "local_replacement": "Mock alert/event ingestion API",
                "endpoint": "POST /api/mock-pagerduty/events",
                "api_key_required": False,
            },
            {
                "suggested": "Datadog API",
                "local_replacement": "Mock observability log search API",
                "endpoint": "POST /api/mock-datadog/logs/search",
                "api_key_required": False,
            },
            {
                "suggested": "Splunk / ELK log query",
                "local_replacement": "Mock Splunk-style search API over local logs",
                "endpoint": "POST /api/mock-splunk/search",
                "api_key_required": False,
            },
            {
                "suggested": "Jira API",
                "local_replacement": "Mock Jira incident search API",
                "endpoint": "POST /api/mock-jira/search",
                "api_key_required": False,
            },
            {
                "suggested": "ServiceNow API",
                "local_replacement": "Mock ServiceNow incident search API",
                "endpoint": "POST /api/mock-servicenow/search",
                "api_key_required": False,
            },
            {
                "suggested": "Slack Incoming Webhook",
                "local_replacement": "Local incident channel and webhook simulator",
                "endpoint": "POST /api/mock-slack/webhook",
                "api_key_required": False,
            },
        ],
        "optional_external_integrations": {
            "claude": "Set USE_CLAUDE_API=1 and ANTHROPIC_API_KEY to call Claude instead of only using local AI.",
            "slack": "Set SLACK_WEBHOOK_URL to post to a real Slack channel instead of the local incident channel.",
        },
    }


def query_logs(
    service: str | None = None,
    region: str | None = None,
    start: str | None = None,
    end: str | None = None,
    error_code: str | None = None,
    text: str | None = None,
) -> list[dict[str, Any]]:
    logs = read_json(DATA_DIR / "logs.json")
    start_ts = parse_ts(start) if start else None
    end_ts = parse_ts(end) if end else None
    text_tokens = tokenize(text or "")
    matches: list[dict[str, Any]] = []
    for entry in logs:
        ts = parse_ts(entry["timestamp"])
        if start_ts and ts < start_ts:
            continue
        if end_ts and ts > end_ts:
            continue
        if service and entry.get("service") != service:
            continue
        if region and entry.get("region") != region:
            continue
        if error_code and entry.get("error_code") != error_code:
            continue
        haystack = " ".join(str(value) for value in entry.values())
        if text_tokens and not (text_tokens & tokenize(haystack)):
            continue
        matches.append(entry)
    return matches


def mock_log_search(payload: dict[str, Any], provider: str) -> dict[str, Any]:
    alert = payload.get("alert")
    if alert:
        summary = summarize_logs(alert, read_json(DATA_DIR / "logs.json"))
        return {
            "provider": provider,
            "source": "local-json-log-store",
            "query_type": "alert-correlation-window",
            "summary": summary,
            "logs": summary["important_logs"],
        }

    logs = query_logs(
        service=payload.get("service"),
        region=payload.get("region"),
        start=payload.get("start"),
        end=payload.get("end"),
        error_code=payload.get("error_code"),
        text=payload.get("query") or payload.get("text"),
    )
    return {
        "provider": provider,
        "source": "local-json-log-store",
        "query_type": "field-search",
        "matched_count": len(logs),
        "logs": logs[:50],
    }


def mock_jira_search(payload: dict[str, Any]) -> dict[str, Any]:
    alert = payload.get("alert", payload)
    incidents = rank_incidents(alert, read_json(DATA_DIR / "incidents.json"))
    return {
        "provider": "local-jira",
        "jql": f'project = INCIDENTS AND text ~ "{alert.get("service", "")} {alert.get("error_code", "")}"',
        "matched_count": len(incidents),
        "issues": incidents,
    }


def mock_servicenow_search(payload: dict[str, Any]) -> dict[str, Any]:
    jira_like = mock_jira_search(payload)
    records = []
    for item in jira_like["issues"]:
        records.append(
            {
                "number": item["ticket_id"].replace("INC-", "SN-INC-"),
                "short_description": item["title"],
                "business_service": item["service"],
                "region": item["region"],
                "symptoms": item["symptoms"],
                "root_cause": item["root_cause"],
                "close_notes": item["resolution"],
                "correlation_score": item["similarity_score"],
                "source_link": item["link"],
            }
        )
    return {
        "provider": "local-servicenow",
        "matched_count": len(records),
        "records": records,
    }


def rank_incidents(alert: dict[str, Any], incidents: list[dict[str, Any]]) -> list[dict[str, Any]]:
    alert_text = " ".join(
        str(alert.get(key, ""))
        for key in ("service", "alert_type", "error_code", "description", "region", "severity")
    )
    ranked: list[dict[str, Any]] = []
    for ticket in incidents:
        score = 0.0
        if ticket.get("service") == alert.get("service"):
            score += 0.35
        if alert.get("error_code") and alert.get("error_code") in ticket.get("error_codes", []):
            score += 0.25
        if ticket.get("region") == alert.get("region"):
            score += 0.10
        ticket_text = " ".join(
            str(ticket.get(key, ""))
            for key in ("title", "symptoms", "root_cause", "resolution", "service")
        )
        score += min(text_similarity(alert_text, ticket_text), 0.30)
        ranked_ticket = dict(ticket)
        ranked_ticket["similarity_score"] = round(score, 3)
        ranked.append(ranked_ticket)
    return sorted(ranked, key=lambda item: item["similarity_score"], reverse=True)[:5]


def rank_runbooks(alert: dict[str, Any], runbooks: list[dict[str, str]]) -> list[dict[str, Any]]:
    query = " ".join(str(alert.get(key, "")) for key in ("service", "alert_type", "error_code", "description"))
    ranked: list[dict[str, Any]] = []
    for runbook in runbooks:
        score = text_similarity(query, runbook["title"] + " " + runbook["content"])
        service_slug = alert.get("service", "").lower().replace("_", "-")
        if service_slug and service_slug in runbook["id"].lower():
            score += 0.40
        enriched = dict(runbook)
        enriched["similarity_score"] = round(score, 3)
        enriched["checklist"] = extract_checklist(runbook["content"])
        ranked.append(enriched)
    return sorted(ranked, key=lambda item: item["similarity_score"], reverse=True)[:3]


def evidence_id(entry: dict[str, Any]) -> str:
    return entry.get("id") or entry.get("ticket_id") or entry.get("title") or "evidence"


def build_deterministic_report(
    alert: dict[str, Any],
    log_summary: dict[str, Any],
    similar_incidents: list[dict[str, Any]],
    runbooks: list[dict[str, Any]],
) -> dict[str, Any]:
    exception_logs = log_summary["exception_logs"]
    deployments = log_summary["deployment_events"]
    top_incident = similar_incidents[0] if similar_incidents else {}
    top_runbook = runbooks[0] if runbooks else {}
    top_errors = [code for code, _ in log_summary["top_error_codes"]]
    dependencies = [dep for dep, _ in log_summary["top_dependencies"]]

    hypotheses: list[dict[str, Any]] = []
    signal_text = " ".join(
        entry.get("message", "") + " " + entry.get("error_code", "") + " " + entry.get("dependency", "")
        for entry in log_summary["important_logs"] + log_summary["deployment_events"]
    ).lower()

    def add_hypothesis(hypothesis: str, likelihood: str, evidence: list[str], reasoning: str) -> None:
        if len(hypotheses) >= 3:
            return
        hypotheses.append(
            {
                "rank": len(hypotheses) + 1,
                "hypothesis": hypothesis,
                "likelihood": likelihood,
                "evidence": evidence or ["alert_payload"],
                "reasoning": reasoning,
            }
        )

    db_signal = any(
        any(term in entry.get("message", "").lower() for term in ("pool", "sqlstate", "connection", "database"))
        for entry in exception_logs
    )
    timeout_signal = any("timeout" in entry.get("message", "").lower() for entry in exception_logs)
    kafka_signal = any(term in signal_text for term in ("kafka", "consumer lag", "rebalance", "partition", "broker"))
    search_signal = any(term in signal_text for term in ("elasticsearch", "search-cluster", "shard", "circuit breaker"))
    auth_signal = any(term in signal_text for term in ("jwks", "token signature", "identity-provider", "identity provider"))
    provider_throttle_signal = any(term in signal_text for term in ("429", "throttle", "rate limit"))
    queue_signal = any(term in signal_text for term in ("invoice queue", "queue backlog", "dead-letter", "dlq", "worker saturation"))
    cache_signal = any(term in signal_text for term in ("cache", "redis", "memcached", "miss ratio", "eviction"))

    if db_signal:
        evidence = [evidence_id(entry) for entry in exception_logs[:3]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Database connection pool exhaustion or database connectivity degradation",
            "High",
            evidence,
            "The correlated logs contain connection pool, SQL, or database errors during the alert window, and similar historical incidents point to the same failure mode.",
        )

    if kafka_signal:
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Kafka consumer lag or broker instability is delaying event processing",
            "High",
            evidence,
            "The alert window contains Kafka lag, rebalance, partition, or broker errors that match historical order-processing incidents.",
        )

    if search_signal:
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Elasticsearch shard pressure or circuit breaker failures are causing search errors",
            "High",
            evidence,
            "The logs point to Elasticsearch/search-cluster shard failures, rejected queries, or circuit breaker pressure during the incident window.",
        )

    if auth_signal:
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Identity provider or JWKS cache issue is causing token validation failures",
            "High",
            evidence,
            "The alert window contains JWKS, token signature, or identity-provider validation failures that match previous login incidents.",
        )

    if provider_throttle_signal:
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "External provider throttling is causing request failures",
            "High",
            evidence,
            "The correlated logs include 429/rate-limit/provider-throttle signals and similar incidents show provider quota exhaustion as the root cause.",
        )

    if cache_signal and not any("redis" in item.get("hypothesis", "").lower() for item in hypotheses):
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Cache saturation or cache miss spike is increasing downstream load",
            "Medium",
            evidence,
            "Cache miss, Redis, or eviction signals indicate the service is bypassing hot cache paths and putting pressure on dependencies.",
        )

    if queue_signal:
        evidence = [evidence_id(entry) for entry in log_summary["important_logs"][:4]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Worker queue backlog is delaying asynchronous processing",
            "High" if "backlog" in signal_text else "Medium",
            evidence,
            "Queue depth, dead-letter, or worker retry signals suggest processing is slower than ingestion and user-visible workflows are backing up.",
        )

    if deployments:
        evidence = [evidence_id(entry) for entry in deployments[:2]]
        if top_incident:
            evidence.append(top_incident["ticket_id"])
        add_hypothesis(
            "Recent deployment introduced a regression in the affected service",
            "Medium" if db_signal or kafka_signal or search_signal or provider_throttle_signal or queue_signal else "High",
            evidence,
            "A deployment event appears inside the 30-minute correlation window before the alert. Validate release health and rollback readiness.",
        )

    if timeout_signal or dependencies:
        evidence = [evidence_id(entry) for entry in exception_logs[:3]]
        if dependencies:
            evidence.append("dependency:" + dependencies[0])
        add_hypothesis(
            "Downstream dependency timeout causing cascading 5xx or latency errors",
            "Medium",
            evidence,
            "Timeouts and dependency references are present in the matched logs. Check dependency saturation, network path, and retry behavior.",
        )

    while len(hypotheses) < 3:
        hypotheses.append(
            {
                "rank": len(hypotheses) + 1,
                "hypothesis": "Traffic spike or regional service saturation",
                "likelihood": "Low",
                "evidence": [evidence_id(entry) for entry in log_summary["important_logs"][:2]] or ["alert_payload"],
                "reasoning": "Insufficient stronger signals remain, but regional impact and elevated errors make saturation worth validating.",
            }
        )

    checklist: list[str] = []
    for runbook in runbooks:
        checklist.extend(runbook.get("checklist", []))
    for incident in similar_incidents[:2]:
        if incident.get("resolution"):
            checklist.append(f"Apply historical fix from {incident['ticket_id']}: {incident['resolution']}")
    checklist.extend(
        [
            f"Confirm current error rate and latency for {alert.get('service')} in {alert.get('region')}.",
            "If customer impact is still rising after first mitigation, escalate to the service owner and incident commander.",
        ]
    )
    deduped_checklist = list(dict.fromkeys(checklist))[:8]

    severity = str(alert.get("severity", "")).upper()
    service_name = str(alert.get("service", "affected service"))
    if severity in {"P1", "SEV1", "CRITICAL"}:
        if db_signal:
            escalation = f"Escalate immediately as P1: page {service_name} owner, Database Reliability, and incident commander."
        elif kafka_signal:
            escalation = f"Escalate immediately as P1: page {service_name} owner, Kafka Reliability, and incident commander."
        elif search_signal:
            escalation = f"Escalate immediately as P1: page {service_name} owner, Search Platform, Data Infrastructure, and incident commander."
        elif provider_throttle_signal:
            escalation = f"Escalate immediately as P1: page {service_name} owner, Vendor Management, and incident commander."
        else:
            escalation = f"Escalate immediately as P1: page {service_name} owner and incident commander."
    else:
        escalation = f"Escalate to {service_name} owner if remediation does not reduce impact within 10 minutes."

    report = {
        "source": "local-ai-agent",
        "alert_summary": {
            "service": alert.get("service"),
            "alert_type": alert.get("alert_type"),
            "severity": alert.get("severity"),
            "region": alert.get("region"),
            "timestamp": alert.get("timestamp"),
            "error_code": alert.get("error_code"),
            "description": alert.get("description"),
        },
        "correlation_window": log_summary["window"],
        "log_findings": {
            "matched_count": log_summary["matched_count"],
            "level_counts": log_summary["level_counts"],
            "top_error_codes": top_errors,
            "top_dependencies": dependencies,
        },
        "root_cause_hypotheses": hypotheses[:3],
        "remediation_checklist": deduped_checklist,
        "similar_incidents": similar_incidents[:3],
        "runbooks": [
            {"id": item["id"], "title": item["title"], "similarity_score": item["similarity_score"]}
            for item in runbooks
        ],
        "escalation_recommendation": escalation,
        "validation_warnings": correlation_warnings(log_summary, similar_incidents, runbooks),
    }
    report["slack_message"] = format_slack_message(report)
    return report


def compact_context_for_llm(
    alert: dict[str, Any],
    log_summary: dict[str, Any],
    similar_incidents: list[dict[str, Any]],
    runbooks: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "alert": alert,
        "log_summary": {
            "window": log_summary["window"],
            "matched_count": log_summary["matched_count"],
            "level_counts": log_summary["level_counts"],
            "top_error_codes": log_summary["top_error_codes"],
            "top_dependencies": log_summary["top_dependencies"],
            "exception_logs": log_summary["exception_logs"][:6],
            "deployment_events": log_summary["deployment_events"][:3],
        },
        "similar_incidents": similar_incidents[:5],
        "runbooks": [
            {
                "id": runbook["id"],
                "title": runbook["title"],
                "checklist": runbook.get("checklist", []),
                "excerpt": runbook["content"][:1400],
            }
            for runbook in runbooks
        ],
    }


def extract_json_object(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?", "", stripped).strip()
        stripped = re.sub(r"```$", "", stripped).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start >= 0 and end > start:
        try:
            return json.loads(stripped[start : end + 1])
        except json.JSONDecodeError:
            return None
    return None


def call_claude(context: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
    if not USE_CLAUDE_API:
        return None, "USE_CLAUDE_API is not enabled; used the local AI agent."
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None, "ANTHROPIC_API_KEY is not set; used local fallback triage."

    system_prompt = (
        "You are an incident triage AI agent. Produce a concise, evidence-based incident report. "
        "Use only the provided logs, incidents, and runbooks as evidence. Return valid JSON only."
    )
    user_prompt = {
        "task": "Generate a production incident triage report within the required schema.",
        "required_schema": {
            "source": "claude",
            "alert_summary": "object",
            "correlation_window": "object",
            "log_findings": "object",
            "root_cause_hypotheses": [
                {
                    "rank": "number",
                    "hypothesis": "string",
                    "likelihood": "High | Medium | Low",
                    "evidence": ["specific log id, ticket id, or runbook id"],
                    "reasoning": "string",
                }
            ],
            "remediation_checklist": ["step-by-step commands or checks"],
            "similar_incidents": ["top 3 incident objects"],
            "runbooks": ["matched runbook summaries"],
            "escalation_recommendation": "string",
            "slack_message": "Slack-ready markdown string",
        },
        "context": context,
    }

    body = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": 1800,
        "temperature": 0.2,
        "system": system_prompt,
        "messages": [{"role": "user", "content": json.dumps(user_prompt, indent=2)}],
    }
    request = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "content-type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=35) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        return None, f"Claude API HTTP {exc.code}: {detail[:600]}"
    except Exception as exc:
        return None, f"Claude API request failed: {exc}"

    text_parts: list[str] = []
    for item in payload.get("content", []):
        if item.get("type") == "text":
            text_parts.append(item.get("text", ""))
    parsed = extract_json_object("\n".join(text_parts))
    if not parsed:
        return None, "Claude responded, but the response was not parseable JSON."
    parsed["source"] = "claude"
    if not parsed.get("slack_message"):
        parsed["slack_message"] = format_slack_message(parsed)
    return parsed, None


def format_slack_message(report: dict[str, Any]) -> str:
    summary = report.get("alert_summary", {})
    lines = [
        ":rotating_light: *Incident Triage Report*",
        f"*Service:* {summary.get('service', 'unknown')} | *Region:* {summary.get('region', 'unknown')} | *Severity:* {summary.get('severity', 'unknown')}",
        f"*Alert:* {summary.get('alert_type', 'unknown')} at {summary.get('timestamp', 'unknown')}",
        "",
        "*Top root-cause hypotheses:*",
    ]
    for item in report.get("root_cause_hypotheses", [])[:3]:
        evidence = ", ".join(str(value) for value in item.get("evidence", [])[:4])
        lines.append(
            f"{item.get('rank', '?')}. {item.get('hypothesis', 'Unknown')} - *{item.get('likelihood', 'Unknown')}*"
        )
        if evidence:
            lines.append(f"   Evidence: {evidence}")
    lines.extend(["", "*Recommended remediation:*"])
    for idx, step in enumerate(report.get("remediation_checklist", [])[:6], start=1):
        lines.append(f"{idx}. {step}")
    if report.get("escalation_recommendation"):
        lines.extend(["", f"*Escalation:* {report['escalation_recommendation']}"])
    return "\n".join(lines)


def generate_local_triage(alert: dict[str, Any]) -> dict[str, Any]:
    logs = read_json(DATA_DIR / "logs.json")
    incidents = read_json(DATA_DIR / "incidents.json")
    runbooks = load_runbooks()
    log_summary = summarize_logs(alert, logs)
    similar_incidents = rank_incidents(alert, incidents)
    matched_runbooks = rank_runbooks(alert, runbooks)
    return build_deterministic_report(alert, log_summary, similar_incidents, matched_runbooks)


def generate_triage(alert: dict[str, Any]) -> dict[str, Any]:
    logs = read_json(DATA_DIR / "logs.json")
    incidents = read_json(DATA_DIR / "incidents.json")
    runbooks = load_runbooks()
    log_summary = summarize_logs(alert, logs)
    similar_incidents = rank_incidents(alert, incidents)
    matched_runbooks = rank_runbooks(alert, runbooks)

    fallback = build_deterministic_report(alert, log_summary, similar_incidents, matched_runbooks)
    context = compact_context_for_llm(alert, log_summary, similar_incidents, matched_runbooks)
    claude_report, claude_error = call_claude(context)
    if claude_report:
        claude_report.setdefault("correlation_window", fallback["correlation_window"])
        claude_report.setdefault("log_findings", fallback["log_findings"])
        claude_report.setdefault("similar_incidents", fallback["similar_incidents"])
        claude_report["claude_model"] = ANTHROPIC_MODEL
        claude_report["fallback_available"] = fallback
        return claude_report

    if USE_CLAUDE_API:
        fallback["claude_error"] = claude_error
        fallback["claude_model"] = ANTHROPIC_MODEL
    return fallback


def post_to_slack(message: str) -> dict[str, Any]:
    webhook = os.environ.get("SLACK_WEBHOOK_URL")
    if not webhook:
        return post_to_local_incident_channel(message)
    body = json.dumps({"text": message}).encode("utf-8")
    request = urllib.request.Request(
        webhook,
        data=body,
        headers={"content-type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            response_text = response.read().decode("utf-8", errors="replace")
        return {"posted": True, "message": response_text or "ok"}
    except Exception as exc:
        return {"posted": False, "message": f"Slack post failed: {exc}"}


def load_local_incident_channel() -> list[dict[str, Any]]:
    if not LOCAL_SLACK_PATH.exists():
        return []
    try:
        messages = read_json(LOCAL_SLACK_PATH)
        return messages if isinstance(messages, list) else []
    except json.JSONDecodeError:
        return []


def post_to_local_incident_channel(message: str, channel: str = "#incident-triage") -> dict[str, Any]:
    messages = load_local_incident_channel()
    entry = {
        "id": f"local-{len(messages) + 1:04d}",
        "channel": channel,
        "username": "incident-triage-agent",
        "timestamp": iso_z(datetime.now(timezone.utc)),
        "text": message,
    }
    messages.append(entry)
    write_json(LOCAL_SLACK_PATH, messages[-100:])
    return {
        "posted": True,
        "local": True,
        "message": f"Posted to local incident channel {channel}. No Slack API key required.",
        "entry": entry,
    }


def create_servicenow_assignment(report: dict[str, Any]) -> dict[str, Any]:
    summary = report.get("alert_summary", {})
    owner = find_service_owner(summary.get("service"))
    assignments = load_list(SERVICENOW_ASSIGNMENTS_PATH)
    ticket_number = f"SN-INC-{len(assignments) + 10001}"
    assignment = {
        "number": ticket_number,
        "state": "Assigned",
        "priority": priority_from_severity(summary.get("severity")),
        "assigned_to": owner["name"],
        "assigned_email": owner["email"],
        "assignment_group": owner["team"],
        "service": summary.get("service", "unknown-service"),
        "region": summary.get("region", "unknown-region"),
        "short_description": f"{summary.get('service', 'Service')} - {summary.get('alert_type', 'incident alert')}",
        "root_cause_lead": (report.get("root_cause_hypotheses") or [{}])[0].get("hypothesis", "Pending investigation"),
        "created_at": iso_z(datetime.now(timezone.utc)),
        "source": "OutagePilot AI",
    }
    assignments.append(assignment)
    write_json(SERVICENOW_ASSIGNMENTS_PATH, assignments[-100:])
    return assignment


def send_mock_email(to_email: str, subject: str, body: str, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    outbox = load_list(EMAIL_OUTBOX_PATH)
    email = {
        "id": f"MAIL-{len(outbox) + 5001}",
        "to": to_email,
        "subject": subject,
        "body": body,
        "status": "sent",
        "sent_at": iso_z(datetime.now(timezone.utc)),
        "metadata": metadata or {},
    }
    outbox.append(email)
    write_json(EMAIL_OUTBOX_PATH, outbox[-100:])
    return email


def assign_and_notify(report: dict[str, Any]) -> dict[str, Any]:
    assignment = create_servicenow_assignment(report)
    summary = report.get("alert_summary", {})
    top_hypothesis = (report.get("root_cause_hypotheses") or [{}])[0]
    subject = f"[{assignment['priority']}] {summary.get('service', 'Service')} incident assigned to you"
    body = "\n".join(
        [
            f"Hello {assignment['assigned_to']},",
            "",
            "OutagePilot AI assigned a live incident to you.",
            "",
            f"Service: {summary.get('service', 'unknown')}",
            f"Region: {summary.get('region', 'unknown')}",
            f"Severity: {summary.get('severity', 'unknown')}",
            f"ServiceNow: {assignment['number']}",
            f"Top hypothesis: {top_hypothesis.get('hypothesis', 'Pending investigation')}",
            f"Escalation: {report.get('escalation_recommendation', 'N/A')}",
            "",
            "Open the incident command center for remediation steps and evidence.",
        ]
    )
    email = send_mock_email(
        assignment["assigned_email"],
        subject,
        body,
        {"servicenow_number": assignment["number"], "service": assignment["service"]},
    )
    return {
        "assigned": True,
        "assignment": assignment,
        "email": email,
        "message": f"Assigned {assignment['number']} to {assignment['assigned_to']} and sent email to {assignment['assigned_email']}.",
    }


class IncidentHandler(BaseHTTPRequestHandler):
    server_version = "IncidentTriagePoC/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        print("%s - %s" % (self.address_string(), format % args))

    def send_json(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_static(self, path: Path, content_type: str) -> None:
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("content-type", content_type)
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self) -> dict[str, Any]:
        length = int(self.headers.get("content-length", "0"))
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:
        try:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            query = {key: values[-1] for key, values in urllib.parse.parse_qs(parsed.query).items()}
            if path in {"/", "/index.html"}:
                self.send_static(STATIC_DIR / "index.html", "text/html; charset=utf-8")
            elif path == "/styles.css":
                self.send_static(STATIC_DIR / "styles.css", "text/css; charset=utf-8")
            elif path == "/app.js":
                self.send_static(STATIC_DIR / "app.js", "application/javascript; charset=utf-8")
            elif path == "/api/alerts":
                self.send_json(load_all_alerts())
            elif path == "/api/error-payloads":
                self.send_json(list_named_json_files(ERROR_PAYLOAD_DIR))
            elif path == "/api/local-stack":
                self.send_json(local_stack_status())
            elif path == "/api/slack/messages":
                self.send_json(load_local_incident_channel())
            elif path == "/api/mock-datadog/logs/search":
                self.send_json(mock_log_search(query, "local-datadog"))
            elif path == "/api/mock-splunk/search":
                self.send_json(mock_log_search(query, "local-splunk"))
            elif path == "/api/mock-jira/search":
                self.send_json(mock_jira_search(query))
            elif path == "/api/mock-servicenow/search":
                self.send_json(mock_servicenow_search(query))
            elif path == "/api/mock-servicenow/assignments":
                self.send_json(load_list(SERVICENOW_ASSIGNMENTS_PATH))
            elif path == "/api/mock-email/outbox":
                self.send_json(load_list(EMAIL_OUTBOX_PATH))
            elif path == "/api/health":
                self.send_json(
                    {
                        "ok": True,
                        "local_ai_enabled": True,
                        "use_claude_api": USE_CLAUDE_API,
                        "claude_configured": bool(os.environ.get("ANTHROPIC_API_KEY")),
                        "slack_configured": bool(os.environ.get("SLACK_WEBHOOK_URL")),
                        "local_slack_enabled": True,
                        "model": ANTHROPIC_MODEL,
                    }
                )
            else:
                self.send_json({"error": "not found"}, status=404)
        except Exception as exc:
            traceback.print_exc()
            self.send_json({"error": str(exc)}, status=500)

    def do_POST(self) -> None:
        try:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            body = self.read_body()
            if path == "/api/triage":
                if "sample_id" in body:
                    alerts = read_json(DATA_DIR / "sample_alerts.json")
                    alert = next((item for item in alerts if item["id"] == body["sample_id"]), alerts[0])
                else:
                    alert = body.get("alert") or body.get("payload") or body
                validation = validation_error_response(alert)
                if validation:
                    self.send_json(validation, status=400)
                    return
                self.send_json(generate_triage(alert))
            elif path == "/api/local-ai/triage":
                if "sample_id" in body:
                    alerts = read_json(DATA_DIR / "sample_alerts.json")
                    alert = next((item for item in alerts if item["id"] == body["sample_id"]), alerts[0])
                else:
                    alert = body.get("alert") or body.get("payload") or body
                validation = validation_error_response(alert)
                if validation:
                    self.send_json(validation, status=400)
                    return
                self.send_json(generate_local_triage(alert))
            elif path == "/api/alerts/save":
                alert = body.get("alert") or body.get("payload") or body
                result = save_alert_payload(alert)
                self.send_json(result, status=200 if result.get("saved") else 400)
            elif path == "/api/mock-pagerduty/events":
                alert = body.get("alert") or body.get("payload") or body
                validation = validation_error_response(alert)
                if validation:
                    self.send_json(
                        {
                            "provider": "local-pagerduty",
                            "status": "rejected",
                            "message": "Mock PagerDuty event rejected by local alert validation.",
                            **validation,
                        },
                        status=400,
                    )
                    return
                self.send_json(
                    {
                        "provider": "local-pagerduty",
                        "status": "triggered",
                        "dedup_key": alert.get("id", f"local-event-{datetime.now(timezone.utc).timestamp()}"),
                        "message": "Mock PagerDuty event accepted and triaged locally.",
                        "triage_report": generate_triage(alert),
                    }
                )
            elif path == "/api/mock-datadog/logs/search":
                self.send_json(mock_log_search(body, "local-datadog"))
            elif path == "/api/mock-splunk/search":
                self.send_json(mock_log_search(body, "local-splunk"))
            elif path == "/api/mock-jira/search":
                self.send_json(mock_jira_search(body))
            elif path == "/api/mock-servicenow/search":
                self.send_json(mock_servicenow_search(body))
            elif path == "/api/mock-servicenow/assign":
                report = body.get("report", body)
                self.send_json(assign_and_notify(report))
            elif path == "/api/mock-email/send":
                self.send_json(
                    send_mock_email(
                        body.get("to", "platform-oncall@example.local"),
                        body.get("subject", "OutagePilot AI incident notification"),
                        body.get("body", ""),
                        body.get("metadata", {}),
                    )
                )
            elif path == "/api/slack":
                message = body.get("message", "")
                self.send_json(post_to_slack(message))
            elif path == "/api/slack/clear":
                write_json(LOCAL_SLACK_PATH, [])
                self.send_json({"cleared": True, "message": "Local incident channel cleared."})
            elif path == "/api/mock-slack/webhook":
                message = body.get("text") or body.get("message", "")
                channel = body.get("channel", "#incident-triage")
                self.send_json(post_to_local_incident_channel(message, channel))
            else:
                self.send_json({"error": "not found"}, status=404)
        except Exception as exc:
            traceback.print_exc()
            self.send_json({"error": str(exc)}, status=500)


def main() -> None:
    address = (HOST, PORT)
    server = ThreadingHTTPServer(address, IncidentHandler)
    print(f"Incident Triage AI Agent PoC running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    server.serve_forever()


if __name__ == "__main__":
    main()
