# OutagePilot AI

Zero-dependency local hackathon PoC for correlating alerts, logs, runbooks, and historical incidents into a structured triage report.

Tagline: **From alert storm to accountable action in under 90 seconds.**

The app runs as its own mini incident platform. It does not need Claude, PagerDuty, Datadog, Splunk, Jira, ServiceNow, or Slack keys.

## Run Locally

PowerShell:

```powershell
python app.py
```

Then open:

```text
http://127.0.0.1:8000
```

Optional real integrations are still possible later, but the default demo is fully local.

## What Is Included

- Local HTML/CSS/JS web UI
- Python standard-library web server
- Mock alert ingestion
- 30-minute log correlation window
- Similar historical incident ranking
- Markdown runbook retrieval
- Local AI reasoning engine
- Slack-formatted incident report
- Local Slack-like incident channel
- Mock APIs for PagerDuty, Datadog, Splunk, Jira, and ServiceNow
- Visual command center with severity gauge, charts, evidence flow, and collapsible detail panels
- Guided demo mode, mock PagerDuty trigger, payload validation, business impact metrics, service topology, mitigation board, and war-room activity feed
- Automatic mock ServiceNow assignment and mock email notification to the service owner after every generated report
- JSON file upload, editable alert form, severity/value changes, and local JSON save support

## Demo Flow

1. Choose a sample alert from the dropdown.
2. Click **Generate Triage Report**.
3. Review root-cause hypotheses, remediation checklist, evidence, and similar tickets.
4. Copy or post the Slack message preview.

Without `SLACK_WEBHOOK_URL`, the **Post To Incident Channel** button writes to the local simulated channel in the UI. This is useful for demos where you do not have a Slack API key.

## Suggested Stack Replaced Locally

| Suggested Stack | Local Replacement | Endpoint |
|---|---|---|
| Claude Sonnet API | Local AI reasoning engine | `POST /api/local-ai/triage` |
| PagerDuty API | Mock alert/event ingestion | `POST /api/mock-pagerduty/events` |
| Datadog API | Mock log search over local JSON logs | `POST /api/mock-datadog/logs/search` |
| Splunk / ELK query | Mock Splunk-style local search | `POST /api/mock-splunk/search` |
| Jira API | Mock historical incident search | `POST /api/mock-jira/search` |
| ServiceNow API | Mock ServiceNow incident records | `POST /api/mock-servicenow/search` |
| Slack webhook | Local incident channel | `POST /api/mock-slack/webhook` |

Additional workflow endpoints:

```text
POST /api/mock-servicenow/assign
GET  /api/mock-servicenow/assignments
POST /api/mock-email/send
GET  /api/mock-email/outbox
```

Local stack status:

```text
http://127.0.0.1:8000/api/local-stack
```

## Local API Examples

Mock PagerDuty alert trigger:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/mock-pagerduty/events -Method Post -ContentType 'application/json' -Body (Get-Content data\sample_payloads\grafana_orders_kafka_p1.json -Raw)
```

Mock Datadog log search:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/mock-datadog/logs/search -Method Post -ContentType 'application/json' -Body '{"service":"orders-api","region":"ap-south-1","text":"kafka lag"}'
```

Mock Jira similar incident search:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/mock-jira/search -Method Post -ContentType 'application/json' -Body (Get-Content data\sample_payloads\datadog_search_elasticsearch_p1.json -Raw)
```

## Local Slack-Like API

Post a message locally:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/mock-slack/webhook -Method Post -ContentType 'application/json' -Body '{"channel":"#incident-triage","text":"hello from local webhook"}'
```

Read local channel history:

```text
http://127.0.0.1:8000/api/slack/messages
```

## Sample Test Payloads

The UI dropdown reads from `data/sample_alerts.json`. Individual copy-paste payloads are also available in `data/sample_payloads/`:

```text
pagerduty_payments_p1.json
datadog_inventory_latency_p2.json
pagerduty_auth_login_p2.json
grafana_orders_kafka_p1.json
datadog_search_elasticsearch_p1.json
pagerduty_notification_provider_p2.json
servicenow_billing_queue_p2.json
grafana_profile_cache_p3.json
```

## Error Test Payloads

The UI also has **Error test cases** that load from `data/error_payloads/`:

```text
missing_timestamp.json
invalid_timestamp.json
missing_service.json
invalid_severity.json
wrong_shape.json
no_matching_evidence.json
```

Use these to demo validation failures, structured diagnostics, and the warning path for a valid alert with no matching evidence.

## Files

```text
app.py                 Local server, APIs, correlation, AI reasoning, mock stack
data/sample_alerts.json
data/logs.json
data/incidents.json
data/uploaded_alerts.json
runbooks/*.md
static/index.html
static/styles.css
static/app.js
```

## Environment Variables

```text
USE_CLAUDE_API        Optional, set to 1 only if you want real Claude calls
ANTHROPIC_API_KEY     Optional Claude API key
ANTHROPIC_MODEL       Optional, defaults to claude-sonnet-4-20250514
SLACK_WEBHOOK_URL     Optional real Slack incoming webhook URL
PORT                  Optional, defaults to 8000
```
