### Problem Solving:



#### Two pointer:



Solved 2 Sum -> 

* left \& right at two extreme ends
* sorted array in most cases
* while(left < right)
* fix one compare the other pointer \& then increment/decrement
* sample logic -> if greater right -- if lesser left ++
* time complexity -> O(n) -> iterating once through the array in one pass



Next Target 3 Sum \& Other similar ->

* Possible logic for 3 sum -> sorted array -> one outer loop (i) to fix one -> multiple inner loops for 2 pointers -> iterate through conditions





#### Java:



Array impl ->

* empty array -> Integer array\[] = new int\[] 
* empty list -> List<Integer> array = new ArrayList<>()



Strings ->

* String pooling states only object literal can stay in pool -> thread safe, consistency maintained, immutability

String s1 = "Aditi"

s1.concat("Soham") -> Aditi \[goes to garbage collection]

s = s1.concat(" Soham") -> Aditi Soham 



* String objects are allocated in heap

String s1 = new String("Soham") -> creates in heap as well as in pool if literal not present \[2 objects, one reference]



* == -> check if ref equal or not \& .equals() check if value equal or not





### Agentic AI:



* uv -> newest fastest package use for dependency installation and management -> uv init -> template files
* create a python vm -> isolates workspace for project, limits package installation, config under the workspace not globally

uv venm / python -m venv .venv

* Pre-requisites -> API Keys, .env, requirements.txt define \& installation using uv / python 
* i/p -> llm => tools -> o/p ; tools -> functions help give context \& perform task
* tools: """docstring""" -> user\_prompt for more fine tuned \& accurate response, return response string
* new Agent from openAI -> include metadata like model, tools, system\_prompt (prompt given to agent to pre-train \& make context aware), etc ; agent.invoke()
* Chat model and llm model integration from requirements -> langchain-openai, langchain-groq ; model define for openai -> gpt-5.1, google gemini -> google-ai:gemini-flash4.2
* os.environ(API\_KEY) = os.en...(OPENAI\_KEY)
* model define for openai -> gpt-5.1, google gemini -> google-ai:gemini-flash4.2
* Stream() -> pass a prompt \& generate real time response as it generates without waiting for response to complete ; implemented using a loop then agent.invoke()
* Batch(\[], config(max\_concurrent:size)) -> pass multiple prompts to get response with or without defining max parallel llm calls ; implemented using nested loop iterations

### 

